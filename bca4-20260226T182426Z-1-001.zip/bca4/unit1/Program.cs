﻿using System;
namespace unit1
{
    internal class Program
    {
        static void Main()
        {
            Console.Write("enter value of a ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("enter value of b");
            int b = Convert.ToInt32(Console.ReadLine());
            int c = a + b;
            int d = a - b;
            int e = a / b;
            int f = a % b;
            int g = a * b;
            Console.WriteLine("addition" + c);
            Console.WriteLine("subtraction" + d);
            Console.WriteLine("division" + e);
            Console.WriteLine("modulas" + f);
            Console.WriteLine("multiplication" + g);
            


            

        }
    }
}
